﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Morabaraba
{
    class GamePlay
    {
        Player player;
        Canvas board;
      
        List<Ellipse> player1;
        List<Ellipse> player2;
        Structure strct;
        int count1;
        int count2;
        int stage = 0;
        public GamePlay(Canvas board)
        {
            this.board = board;
            player = new Player(board);
            player1 = player.player1List;
            player2 = player.player2List;
            count1 = 0;
            count2 = 0;
        }

        public bool IsGameOver()
        {
            return player.player1List.Count == 2 || player.player2List.Count == 2;
        }

        private Point Position(Point ps)
        {
            return strct.ActaulPoint(ps);
           
        }
        public void Game(Point pos, int turn)
        {
            strct = new Structure(board);
            if (turn == 0)
            {
                strct.MoveCow(new Point(), new Point());
                player.Place(player1[count1], Position(pos));
                count1++;
            }
            else if(turn == 1)
            {
                player.Place(player2[count2], Position(pos));
                count2++;
            }
            
        }
       


        
    }
}
