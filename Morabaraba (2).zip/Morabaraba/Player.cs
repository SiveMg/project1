﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;

namespace Morabaraba
{
    class Player
    {
        public List<Ellipse> player1List; //List containing all the cows of player1
        public List<Ellipse> player2List; //List containing all the cows of player2
        private Canvas board; 
        public Player(Canvas board)
        {
            player1List = new List<Ellipse>();
            player2List = new List<Ellipse>();
            this.board = board;

            CreatePlayers();
        }

        public void CreatePlayers()
        {
            for(int i = 0; i < 12; i++)
            {
                player1List.Add(new Ellipse { Height = 50, Width = 50, Fill = Brushes.Red });
                player2List.Add(new Ellipse { Height = 50, Width = 50, Fill = Brushes.Yellow });
            }
        }

        private Point ActualPoint(Point pnt)
        {

            return new Point(pnt.X - 25, pnt.Y - 25);
        }
        public void Place(Ellipse piece, Point position)
        {
            board.Children.Add(piece);
            position = ActualPoint(position);
            Canvas.SetLeft(piece,position.X);
            Canvas.SetTop(piece, position.Y);
        }
        public void RemovePiece(Point position)
        {

        }
    }
}
