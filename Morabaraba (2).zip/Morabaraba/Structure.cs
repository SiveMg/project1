﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Shapes;

namespace Morabaraba
{
    
    class Structure
    {
        private List<string> positions = new List<string> { "a1", "a4", "a7",
                                                        "b2", "b4", "b6",
                                                        "c3", "c4", "c5",
                                                        "d1", "d2", "d3","d5", "d6", "d7",
                                                        "e3", "e4", "e5",
                                                        "f2", "f4", "f6",
                                                        "g1", "g4", "g7"};
        List<Point> points;
        private Canvas board;
        public Structure(Canvas board)
        {
            
            points = new List<Point>();
            this.board = board;
            AddPoints();
        }

        private void AddPoints()
        {
            List<double> xcoord = new List<double> {4.03, 2.007, 1.335,
                                                    3.01, 2.007, 1.505,
                                                    2.415, 2.007, 1.716,
                                                    4.03, 3.01, 2.415, 1.716, 1.505, 1.335,
                                                    2.415, 2.007, 1.716,
                                                    3.01, 2.007, 1.505,
                                                    4.03, 2.007, 1.335};

            List<double> ycoord = new List<double> {9.05, 9.05, 9.05,
                                                    3.94, 3.94, 4.94,
                                                    2.54, 2.54, 2.54,
                                                    1.868, 1.868, 1.868, 1.868, 1.868, 1.868,
                                                    1.475, 1.475, 1.475,
                                                    1.222, 1.222, 1.222,
                                                    1.042, 1.042, 1.042};
            for(int i = 0; i < 12; i++)
            {
                points.Add(new Point(XCoordinate(xcoord[i]), YCoordinate(ycoord[i])));
            }

        }

        public Point ActaulPoint(Point point)
        {
            foreach(Point pt in points)
            {
                //MessageBox.Show(Convert.ToString(Math.Abs(pt.X ) + " " + Math.Abs(pt.Y)));
                if (Math.Abs(pt.X - point.X) <= 25 && Math.Abs(pt.Y - point.Y) <= 25) return pt;
            }
            return new Point();
        }

        private int XCoordinate(double divider)
        {
            return Convert.ToInt32(board.ActualWidth / divider);
        }

        private int YCoordinate(double divider)
        {
            MessageBox.Show(Convert.ToString(board.ActualHeight / divider));
            return Convert.ToInt32(board.ActualHeight/ divider);
        }
        private bool isNeighbour(string p1, string p2)
        {
            //if()
            return false;
        }
        public void MoveCow(Point from, Point to)
        {
           MessageBox.Show(Convert.ToString(board.ActualHeight));
        }
        //Convert Points on the Canvas to actual game positions
        private string PointsToPosition(Point p1)
        {

            foreach (Point p in points)
            {
                if (p == p1) return positions[points.IndexOf(p)];
            }
            return "";
        }
        //Convert game Postions to Points on the Canvas
        private Point PositionToPoints(string ps)
        {
            foreach (string p in positions)
            {
                if (p == ps) return points[positions.IndexOf(p)];
            }
            return new Point(0, 0);
        }

        private Ellipse Candidate(Point p)
        {
            foreach (object ob in board.Children)
            {
                if (ob is Ellipse)
                {
                    Ellipse x = (Ellipse)ob;
                    if (Canvas.GetLeft(x) + (x.ActualWidth / 2) == p.X && Canvas.GetTop(x) + (x.ActualHeight / 2) == p.Y)
                    {
                        return x;
                    }
                }
            }
            return null;
        }
        //Get pieces from postions
        public UIElement PointToPiece(Point p)
        {
            foreach (Point point in points)
            {
                if (Math.Abs(p.X - point.X) <= 70 && Math.Abs(p.Y - point.Y) <= 70) return Candidate(point);
            }
            return null;
        }
        //Positions from pieces
        //public Point PieceToPoint(Ellipse circle)
        //{

        //}
    }
}
